<?php $__env->startSection('title', 'Pengajuan Proposal'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <h1 class="mb-4">Pengajuan Proposal</h1>

        
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show shadow-sm" role="alert">
                <i class="bi bi-check-circle me-2"></i> <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <a href="<?php echo e(route('admin.layanan.pengajuan_proposal.create')); ?>" class="btn btn-primary mb-3">
            Tambah Pengajuan
        </a>

        <div class="card shadow-sm">
            <div class="card-body table-responsive">
                <table class="table table-bordered table-striped text-center align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>Nama</th>
                            <th>Link</th>
                            <th width="150">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $proposals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proposal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($proposal->nama); ?></td>
                                <td><a href="<?php echo e($proposal->link); ?>" target="_blank"><?php echo e($proposal->link); ?></a></td>
                                <td>
                                    <a href="<?php echo e(route('admin.layanan.pengajuan_proposal.edit', $proposal->id)); ?>"
                                        class="btn btn-sm btn-warning me-1">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                    <form action="<?php echo e(route('admin.layanan.pengajuan_proposal.destroy', $proposal->id)); ?>"
                                        method="POST" class="d-inline"
                                        onsubmit="return confirm('Yakin hapus pengajuan ini?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-sm btn-danger"><i class="bi bi-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="3" class="text-center text-muted">Belum ada pengajuan</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/alfarish/Developer/Web/desa_pabuaran/resources/views/admin/layanan/pengajuan_proposal/pengajuan_proposal.blade.php ENDPATH**/ ?>