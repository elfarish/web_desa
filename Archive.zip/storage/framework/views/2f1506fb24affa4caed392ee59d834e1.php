<nav class="navbar navbar-light bg-white shadow-sm px-4 d-flex justify-content-between">
    <span class="navbar-text">
        Halo, <strong><?php echo e(Auth::user()->name ?? 'Admin'); ?></strong>
    </span>
    <form method="POST" action="<?php echo e(route('logout')); ?>">
        <?php echo csrf_field(); ?>
        <button class="btn btn-sm btn-danger">
            <i class="bi bi-box-arrow-right me-1"></i> Logout
        </button>
    </form>
</nav>
<?php /**PATH /Users/alfarish/Developer/Web/desa_pabuaran/resources/views/partials/admin/navbar.blade.php ENDPATH**/ ?>